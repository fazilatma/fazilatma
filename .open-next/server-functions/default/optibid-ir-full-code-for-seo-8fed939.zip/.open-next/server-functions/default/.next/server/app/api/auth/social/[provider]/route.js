var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/social/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__0bk3or3._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0ec8jyy.js")
R.c("server/chunks/src_lib_json-store_ts_0m90tqd._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_social_[provider]_route_actions_1d7od8p.js")
R.m(20523)
module.exports=R.m(20523).exports
