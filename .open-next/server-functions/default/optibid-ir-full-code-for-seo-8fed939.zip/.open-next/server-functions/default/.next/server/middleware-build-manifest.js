globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Ta1Liyjbqb2X-6CmIhu_x/_buildManifest.js",
    "static/Ta1Liyjbqb2X-6CmIhu_x/_ssgManifest.js",
    "static/Ta1Liyjbqb2X-6CmIhu_x/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ajvu76j45id7.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/2757xz5q1tv03.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-1q90i1pv3h-mj.js"
  ]
};
