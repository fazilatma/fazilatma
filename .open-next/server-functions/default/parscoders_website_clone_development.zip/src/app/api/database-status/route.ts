import { NextResponse } from "next/server";
import { getJsonStorageInfo, getOptiBidData } from "@/lib/json-store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await getOptiBidData();
    const storage = getJsonStorageInfo();

    return NextResponse.json({
      ok: true,
      storage: "JSON file",
      writableFile: storage.dataFile,
      counts: {
        requests: data.requests.length,
        users: data.users.length,
        orders: data.orders.length,
        transactions: data.transactions.length,
      },
      message: "ذخیره‌سازی JSON برای OptiBid آماده ثبت درخواست است.",
      note:
        "برای ماندگاری بین ری‌استارت‌ها در PaaS، متغیر OPTIBID_DATA_FILE را به مسیر دیسک پایدار متصل‌شده تنظیم کنید.",
    });
  } catch (error) {
    const detail = error instanceof Error ? error.message : "Unknown JSON storage error";
    return NextResponse.json(
      {
        ok: false,
        storage: "JSON file",
        message: "فایل JSON قابل خواندن یا نوشتن نیست.",
        detail,
      },
      { status: 500 }
    );
  }
}
