import { NextResponse } from "next/server";
import AdmZip from "adm-zip";
import path from "path";
import fs from "fs";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const zip = new AdmZip();
    const projectRoot = process.cwd();

    // پوشه‌ها و فایل‌های مهم برای اضافه شدن به زیپ
    const foldersToInclude = ["src", "data"];
    const filesToInclude = [
      "package.json",
      "tsconfig.json",
      "drizzle.config.json",
      "next.config.ts",
      "postcss.config.mjs",
      "eslint.config.mjs",
      "README.md",
      "README_DEPLOY.md",
      "README_SELLER_RATING.md",
      "liara.json",
      ".env.example",
    ];

    // اضافه کردن پوشه‌ها
    for (const folder of foldersToInclude) {
      const folderPath = path.join(/*turbopackIgnore: true*/ projectRoot, folder);
      if (fs.existsSync(folderPath)) {
        zip.addLocalFolder(folderPath, folder);
      }
    }

    // اضافه کردن فایل‌های ریشه
    for (const file of filesToInclude) {
      const filePath = path.join(/*turbopackIgnore: true*/ projectRoot, file);
      if (fs.existsSync(filePath)) {
        zip.addLocalFile(filePath);
      }
    }

    // ایجاد بافر فایل زیپ
    const zipBuffer = zip.toBuffer();
    const uint8Array = new Uint8Array(zipBuffer);

    // ارسال به کاربر برای دانلود مستقیم
    return new NextResponse(uint8Array, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="parscoders-marketplace-source-code.zip"',
      },
    });
  } catch (error) {
    console.error("Error generating zip:", error);
    return NextResponse.json({ error: "Failed to generate zip file" }, { status: 500 });
  }
}
