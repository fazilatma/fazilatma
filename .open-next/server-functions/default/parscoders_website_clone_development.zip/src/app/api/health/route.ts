import { NextResponse } from "next/server";
import { getOptiBidData } from "@/lib/json-store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await getOptiBidData();

    return NextResponse.json({
      ok: true,
      service: "OptiBid",
      storage: "json",
      requests: data.requests.length,
      timestamp: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json(
      { ok: false, service: "OptiBid", storage: "json" },
      { status: 500 }
    );
  }
}
